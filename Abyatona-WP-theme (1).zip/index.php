<?php 
/**
 * Template: Index template
 *
 * @package Abyatona
 * @subpackage Abyatona
 * @since Abyatona
 */
get_header();
?>

    <?php include(PATHLOCAL.'/navbarv2.php'); ?>
    <?php include(PATHLOCAL.'/templates/templateparts/projectCard.php'); ?>
    <?php include(PATHLOCAL.'/templates/templateparts/partnerSection.php'); ?>

  <?php 
  get_footer(); ?>